java -Djava.library.path=./lib/ -jar Dominoes-0.0.1-SNAPSHOT-jfx.jar
